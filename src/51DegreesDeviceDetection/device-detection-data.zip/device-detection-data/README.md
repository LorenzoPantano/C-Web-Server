![51Degrees](https://51degrees.com/DesktopModules/FiftyOne/Distributor/Logo.ashx?utm_source=github&utm_medium=repository&utm_content=home&utm_campaign=c-open-source "Data rewards the curious") **Device Detection Data Files**

# Introduction

This repository contains the freely available 'lite' version of the 51Degrees device detection data file.

It has fewer properties, is built from a subsection of all devices and is updated less frequently than the paid-for data files.

This repository uses [Git LFS](https://git-lfs.github.com/) rather than storing these large binary files directly.
